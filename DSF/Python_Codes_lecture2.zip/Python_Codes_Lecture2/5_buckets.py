#Lists are enclosed in brackets [ ],and their elements and size can be changed
# Example of List are:
aList = [1, 2, 3, 4]
print(aList) 
print(aList[0]) 
print(aList[2:]) 
print(aList[:3]) 
aList[1] = 5
print(aList)

#Tuple are enclosed in brackets ( ),but their elements and size cannot be changed
# Example of Tuple are:
aTuple = ('robots', 77, 93, 'try')
print(aTuple) 
aTuple[1] = 5
print(aTuple)