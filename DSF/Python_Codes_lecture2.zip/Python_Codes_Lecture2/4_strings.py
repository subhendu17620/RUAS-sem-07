# Here are some examples of strings and string usage
pystr_1 = 'Welcome to Python'
pystr_2 = "for Data Science"
print(pystr_1 + pystr_2)
print(pystr_1 + ' ' + pystr_2)
print(pystr_2* 2)
print('-'* 20)

# Slice Operator
print(pystr_1[0])
print(pystr_1[0:7])
print(pystr_2[:8])
print(pystr_2[9:])
