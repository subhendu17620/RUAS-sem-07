#Demonstration of If statement
counter = 7
if counter > 5:
    print ('value is greater than 5')

# counter_2 = 3
# if counter_2 > 5:
#     print ('value is greater than 5')
# else:
#     print ('value is smaller than 5')

# counter_3 = 5
# if counter_3 > 5:
#     print ('value is greater than 5')
# elif counter_3 == 5:
#     print ('value is equal to 5')
# else:
#     print ('value is smaller than 5')