# First Program to print a simple statement
print("Welcome to the Python for Data Science Class")