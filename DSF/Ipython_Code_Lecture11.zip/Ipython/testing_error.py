a = 5
b = 6
assert(a + b == 10)